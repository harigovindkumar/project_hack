package LoginPage;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Login
{
public void data(String Username,String Password)
{
if(Username.equals(Password))
{
	System.out.println("Welcome:"+Username);
}
else 
{
	System.out.println("Please try after few minutes.....");
}
	
}
		
public static void main(String[] args) 
{
	Scanner sc1=new Scanner(System.in);
	System.out.println("Enter the userName:");
	String Username=sc1.next();
	System.out.println("Enter the password:");
	String Password=sc1.next();
	
	Login l1=new Login();
	l1.data("Amal", "amal");
	l1.data("Ajay","ajay");
}
}
