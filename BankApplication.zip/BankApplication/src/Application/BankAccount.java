package Application;

import java.util.Scanner;

public class BankAccount
{
public static void main(String[] args)
{
	BankDetail b1=new BankDetail("Hari", 123);
	//BankDetail b2=new BankDetail("Amal",456);
	b1.ShowData();
	//b2.ShowData();
	
}
}

class BankDetail
{
	double balance;
	double PreviousTransaction;
	String CustomerName;
	int CustomerId;
	
	BankDetail(String name,int id)
	{
		CustomerName=name;
		CustomerId=id;
	}
	
	void deposit(double Amount)
	{
		if(Amount!=0)
		{
			balance=balance+Amount;
			PreviousTransaction=Amount;
			
		}
	}
		
		void Withdrawn(double Amount)
		{
			if(balance!=0)
			{
			balance=balance-Amount;
			PreviousTransaction=-Amount;
			}
		}
		
		void getPreviousTransaction()
		{
			if(PreviousTransaction>0)
			{
				System.out.println("Deposit Amount is:"+PreviousTransaction);
			}
			else if(PreviousTransaction<0)
			{
				System.out.println("Previous transaction is:"+Math.abs(PreviousTransaction));
			}
			else
			{
				System.out.println("no data found");
			}
		}
		void ShowData()
		{
			char option='\0';
			Scanner sc1=new Scanner(System.in);
			System.out.println("Customer Name:"+CustomerName);
			System.out.println("Customer id:"+CustomerId);
			System.out.println("WELCOME TO HGK BANK");
			System.out.println("A.Balance Enquiry:");
			System.out.println("B.Deposit");
			System.out.println("C.Withdrawn");
			System.out.println("D.PreviousTransaction");
			
		
           do
           {
        	  
               System.out.println("Enter the option");
               option=sc1.next().charAt(0);
               System.out.println("\n");
              
           
			switch(option)
			{
		        	
			    case 'A':
//				System.out.println("******************************************");
				System.out.println("The clear balance is:"+balance);
//				System.out.println("******************************************");
				
				break;
				
			    case 'B':
			    	System.out.println("Enter the amount for deposit:");
			    	double d1=sc1.nextDouble();
			    	deposit(d1);
			    	break;
			   
			    case 'C':
//			    	System.out.println("****************************************");
			    	System.out.println("Enter the withdrawn amount:");
			    	double d2=sc1.nextDouble();
			    	Withdrawn(d2);
//			    	System.out.println("***************************************");
			    	break;
			    	
			    case 'D':
//			    	System.out.println("*******************************************");
			    	getPreviousTransaction();
//			        System.out.println("*******************************************");	
			    	break;
				default:
					System.out.println("Invalid option..");
			}
           }
			while(option!='E');
			{
				System.out.println("Thank you for using our services ):");
			}
           }
		}
			

